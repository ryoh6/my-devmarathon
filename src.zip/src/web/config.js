const config = {
  apiUrl: "http://localhost:4183",
};

export default config;
